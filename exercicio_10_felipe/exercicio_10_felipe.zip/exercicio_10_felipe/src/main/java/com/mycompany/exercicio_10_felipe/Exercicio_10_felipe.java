package com.mycompany.exercicio_10_felipe ; 
public class Exercicio_10_felipe {
    public static void main(String[] args) {
        int numero = 10;

        // Laço WHILE para realizar a contagem regressiva
        while (numero >= 0) {
            System.out.println(numero);
            numero--; // Decrementa o número
        }
    }
}
