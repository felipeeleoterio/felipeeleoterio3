/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author HOME
 */
import java.util.LinkedList;
import java.util.Queue;

public class Mavenproject1 {
    public static void main(String[] args) {
        final int TEMPO_TOTAL = 600; // Tempo total da simulação em segundos (10 minutos)
        final int TEMPO_VERDE = 30;  // Tempo do semáforo verde em segundos
        final int TEMPO_AMARELO = 5;  // Tempo do semáforo amarelo em segundos
        final int TEMPO_VERMELHO = 45; // Tempo do semáforo vermelho em segundos
        final int INTERVALO_CHEGADA_CARROS = 15; // Intervalo de chegada dos carros em segundos
        final int CAPACIDADE_MAX_FILA = 10; // Capacidade máxima da fila

        
        Interseccao[] interseccoes = new Interseccao[3];
        for (int i = 0; i < interseccoes.length; i++) {
            interseccoes[i] = new Interseccao();
        }

        // Simulação
        for (int tempo = 0; tempo < TEMPO_TOTAL; tempo++) {
            // Atualiza e imprime o estado dos semáforos
            for (int i = 0; i < interseccoes.length; i++) {
                interseccoes[i].atualizarEstadoSemaforo(tempo);
                interseccoes[i].imprimirEstadoSemaforo();
            }

            // Adiciona novos carros
            if (tempo % INTERVALO_CHEGADA_CARROS == 0) {
                for (Interseccao interseccao : interseccoes) {
                    interseccao.adicionarCarro();
                }
            }

            // Processa o movimento dos carros
            for (Interseccao interseccao : interseccoes) {
                interseccao.processarCarros();
            }

            // Espera 1 segundo
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Relatório final
        for (int i = 0; i < interseccoes.length; i++) {
            interseccoes[i].imprimirRelatorioFinal();
        }
    }
}

class Interseccao {
    private static final int TEMPO_VERDE = 30;
    private static final int TEMPO_AMARELO = 5;
    private static final int TEMPO_VERMELHO = 45;
    private int tempoSemaforo;
    private String estadoSemaforo;
    private Queue<Carro> filaCarros;
    private int totalCarrosPassaram;
    private int carrosNoCongestionamento;
    private long tempoTotalEspera;

    public Interseccao() {
        filaCarros = new LinkedList<>();
        tempoSemaforo = 0;
        estadoSemaforo = "Vermelho";
        totalCarrosPassaram = 0;
        carrosNoCongestionamento = 0;
        tempoTotalEspera = 0;
    }

    public void atualizarEstadoSemaforo(int tempo) {
        int ciclo = (tempo % (TEMPO_VERDE + TEMPO_AMARELO + TEMPO_VERMELHO));
        if (ciclo < TEMPO_VERDE) {
            estadoSemaforo = "Verde";
        } else if (ciclo < TEMPO_VERDE + TEMPO_AMARELO) {
            estadoSemaforo = "Amarelo";
        } else {
            estadoSemaforo = "Vermelho";
        }
    }

    public void imprimirEstadoSemaforo() {
        System.out.println("Estado do semáforo: " + estadoSemaforo);
    }

    public void adicionarCarro() {
        if (filaCarros.size() >= 10) {
            carrosNoCongestionamento++;
        } else {
            filaCarros.add(new Carro(System.currentTimeMillis()));
        }
    }

    public void processarCarros() {
        if ("Verde".equals(estadoSemaforo)) {
            Carro carro = filaCarros.poll();
            if (carro != null) {
                totalCarrosPassaram++;
                tempoTotalEspera += (System.currentTimeMillis() - carro.getTempoChegada());
            }
        }
    }

    public void imprimirRelatorioFinal() {
        System.out.println("Relatório final da interseção:");
        System.out.println("Total de carros que passaram: " + totalCarrosPassaram);
        System.out.println("Tempo médio de espera dos carros: " + (totalCarrosPassaram > 0 ? (tempoTotalEspera / totalCarrosPassaram) / 1000.0 : 0) + " segundos");
        System.out.println("Número de carros presos no congestionamento: " + carrosNoCongestionamento);
    }
}

class Carro {
    private long tempoChegada;

    public Carro(long tempoChegada) {
        this.tempoChegada = tempoChegada;
    }

    public long getTempoChegada() {
        return tempoChegada;
    }
}



